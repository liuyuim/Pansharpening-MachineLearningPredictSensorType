function Qvaule = QNR( Fusimg )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


end

